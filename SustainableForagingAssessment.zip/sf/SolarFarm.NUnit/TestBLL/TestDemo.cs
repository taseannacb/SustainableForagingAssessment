﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolarFarm.NUnit.TestBLL
{
    public class TestDemo
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void Test()
        {
            // --- Basic Test loop for all test cases ---

            //  set up test conditions

            //  Execute the code

            //  verify results

        }

    }
}
